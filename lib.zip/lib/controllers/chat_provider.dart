import 'package:shared_preferences/shared_preferences.dart';

import 'dart:async';
import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:uuid/uuid.dart';

import '../models/mensagem_model.dart';
import '../services/chat_service.dart';
import '../services/realtime_service.dart';
import '../services/api_config.dart';

class ChatProvider extends ChangeNotifier {
  final ChatService service;
  final RealtimeService realtime;
  ChatProvider({ChatService? service, RealtimeService? realtime})
    : service = service ?? ChatService(),
      realtime = realtime ?? RealtimeService() {
    ApiConfig.session.addListener(_session);
  }
  final List<MensagemModel> mensagens = [];
  String? conversaId, erro;
  bool loading = false, enviando = false, ultima = false, _disposed = false;
  bool _loadingHistory = false;
  bool _pendingHistoryReset = false;
  Completer<void>? _historyCompletion;
  Completer<void>? _pendingResetCompletion;
  int _generation = 0;
  int _page = 0;
  Timer? _timeout;
  String? _pendingId, _pendingText;
  String? get textoPendente => _pendingText;
  String? get idPendente => _pendingId;
  String? _pendingKey;
  Future<void> _storage = Future<void>.value();
  Future<void> _persistirPendente(String key, String value) {
    _storage = _storage.catchError((Object _) {}).then((_) async {
      if (!await (await SharedPreferences.getInstance()).setString(
        key,
        value,
      )) {
        throw StateError(
          'Não foi possível salvar a mensagem no aparelho. Ela não foi enviada. Libere espaço e tente novamente.',
        );
      }
    });
    return _storage;
  }

  Future<void> _removerConfirmado(String key, String id) {
    _storage = _storage.catchError((Object _) {}).then((_) async {
      final prefs = await SharedPreferences.getInstance();
      final saved = prefs.getString(key);
      if (saved != null && (jsonDecode(saved) as Map)['id'] == id) {
        await prefs.remove(key);
      }
    });
    return _storage.catchError((Object _) {});
  }

  bool get envioSemConfirmacao => _pendingId != null && !enviando;
  bool get connected => realtime.connected;
  void _notify() {
    if (!_disposed) notifyListeners();
  }

  void _session() {
    realtime.dispose();
    _timeout?.cancel();
    _generation++;
    _loadingHistory = false;
    conversaId = null;
    mensagens.clear();
    enviando = false;
    loading = false;
    ultima = false;
    _page = 0;
    _pendingId = null;
    _pendingText = null;
    _pendingKey = null;
    _pendingHistoryReset = false;
    _pendingResetCompletion?.complete();
    _pendingResetCompletion = null;
    if (!ApiConfig.temSessaoSalva) erro = 'Sessão encerrada.';
    _notify();
  }

  Future<void> abrir(String loja) async {
    final generation = ++_generation;
    conversaId = null;
    _timeout?.cancel();
    _pendingId = null;
    _pendingText = null;
    _pendingKey = null;
    enviando = false;
    realtime.dispose();
    _loadingHistory = false;
    _pendingHistoryReset = false;
    _pendingResetCompletion?.complete();
    _pendingResetCompletion = null;
    mensagens.clear();
    _page = 0;
    ultima = false;
    loading = true;
    erro = null;
    _notify();
    try {
      final id = await service.abrir(loja);
      if (_disposed || generation != _generation) return;
      conversaId = id;
      _pendingKey = ApiConfig.usuarioId == null
          ? null
          : 'chat_pending_${ApiConfig.usuarioId}_$id';
      if (_pendingKey != null) {
        final saved = (await SharedPreferences.getInstance()).getString(
          _pendingKey!,
        );
        if (_disposed || generation != _generation) return;
        if (saved != null) {
          try {
            final pending = jsonDecode(saved) as Map;
            _pendingId = pending['id'] as String;
            _pendingText = pending['text'] as String;
          } catch (_) {
            _pendingId = null;
            _pendingText = null;
            // Um rascunho inválido não deve impedir a abertura da conversa.
          }
        }
      }
      realtime.listen('/topic/conversas/$conversaId', (body) {
        try {
          final m = MensagemModel.fromJson(jsonDecode(body));
          receber(m);
          service.marcarLida(conversaId!).catchError((Object e) {
            erro = e.toString();
            _notify();
          });
        } catch (_) {
          erro = 'Mensagem inválida recebida.';
          _notify();
        }
      });
      realtime.listen('/user/queue/erros', (body) {
        try {
          erro = (jsonDecode(body) as Map)['erro']?.toString();
        } catch (_) {
          erro = 'Não foi possível enviar a mensagem.';
        }
        enviando = false;
        _timeout?.cancel();
        _notify();
      });
      realtime.onConnected = () {
        erro = null;
        carregar(reset: true);
        _notify();
      };
      realtime.onError = (message) {
        erro = message;
        _notify();
      };
      realtime.connect();
      await carregar(reset: true);
    } catch (e) {
      if (generation == _generation && !_disposed) erro = e.toString();
    } finally {
      if (generation == _generation) {
        loading = false;
        _notify();
      }
    }
  }

  void receber(MensagemModel m, {bool notify = true}) {
    if (_disposed || m.conversaId != conversaId) return;
    mensagens.removeWhere((old) => old.id == m.id);
    mensagens.add(m);
    if (notify) mensagens.sort((a, b) => a.enviadaEm.compareTo(b.enviadaEm));
    if (_pendingId != null && m.id == 'msg_$_pendingId') {
      final confirmedId = _pendingId!;
      enviando = false;
      _pendingId = null;
      _pendingText = null;
      if (_pendingKey != null) {
        final key = _pendingKey!;
        unawaited(_removerConfirmado(key, confirmedId));
      }
      _timeout?.cancel();
      erro = null;
    }
    if (notify) _notify();
  }

  Future<void> carregar({bool reset = false}) async {
    if (conversaId == null || _disposed) return;
    if (_loadingHistory) {
      if (reset) {
        _pendingHistoryReset = true;
        _pendingResetCompletion ??= Completer<void>();
        await _pendingResetCompletion!.future;
      } else {
        await _historyCompletion?.future;
      }
      return;
    }
    _loadingHistory = true;
    final completion = Completer<void>();
    _historyCompletion = completion;
    final generation = _generation;
    final id = conversaId!;
    try {
      final result = await service.historico(id, reset ? 0 : _page);
      if (_disposed || generation != _generation || conversaId != id) return;
      if (reset) _page = 0;
      for (final m in result.mensagens) {
        receber(m, notify: false);
      }
      mensagens.sort((a, b) => a.enviadaEm.compareTo(b.enviadaEm));
      _page++;
      ultima = result.last;
      await service.marcarLida(id);
    } catch (e) {
      if (generation == _generation && !_disposed) erro = e.toString();
    } finally {
      if (generation == _generation && !_disposed) {
        _loadingHistory = false;
        _notify();
      }
      completion.complete();
      if (identical(_historyCompletion, completion)) _historyCompletion = null;
      if (generation == _generation && !_disposed && _pendingHistoryReset) {
        _pendingHistoryReset = false;
        final pending = _pendingResetCompletion;
        _pendingResetCompletion = null;
        try {
          await carregar(reset: true);
        } finally {
          if (pending != null && !pending.isCompleted) pending.complete();
        }
      }
    }
  }

  Future<void> tentarNovamente(String loja) async {
    if (conversaId == null) {
      await abrir(loja);
      return;
    }
    realtime.reconnect();
    await carregar(reset: true);
  }

  bool reenviarPendente() {
    if (_pendingId == null ||
        _pendingText == null ||
        !connected ||
        enviando ||
        conversaId == null) {
      return false;
    }
    return _enviarComId(_pendingText!, _pendingId!);
  }

  bool enviar(String text) {
    final value = text.trim();
    if (!connected ||
        enviando ||
        conversaId == null ||
        value.isEmpty ||
        value.length > 4000) {
      return false;
    }
    if (_pendingId != null) return false;
    return _enviarComId(value, const Uuid().v4());
  }

  bool _enviarComId(String value, String id) {
    _pendingId = id;
    _pendingText = value;
    enviando = true;
    erro = null;
    final generation = _generation;
    unawaited(_persistirEEnviar(value, id, generation));
    _notify();
    return true;
  }

  Future<void> _persistirEEnviar(
    String value,
    String id,
    int generation,
  ) async {
    try {
      if (_pendingKey != null) {
        await _persistirPendente(
          _pendingKey!,
          jsonEncode({'id': id, 'text': value}),
        );
      }
      if (_disposed || generation != _generation) return;
      realtime.send('/app/conversas/$conversaId/enviar', {
        'conteudo': value,
        'clientMessageId': id,
      });
      _timeout?.cancel();
      _timeout = Timer(const Duration(seconds: 15), () {
        enviando = false;
        erro = 'Mensagem sem confirmação. Consulte o histórico ou reenvie a mesma mensagem.';
        _notify();
      });
    } catch (e) {
      if (_disposed || generation != _generation) return;
      enviando = false;
      erro = e.toString();
      _notify();
    }
  }

  @override
  void dispose() {
    _disposed = true;
    _timeout?.cancel();
    realtime.dispose();
    if (_pendingResetCompletion case final pending?) {
      if (!pending.isCompleted) pending.complete();
    }
    ApiConfig.session.removeListener(_session);
    super.dispose();
  }
}
